package com.vibe.assistpicker

import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.content.Intent

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad * 2, pad, pad)

        fun label(s: String): TextView {
            val t = TextView(this)
            t.text = s
            t.textSize = 16f
            t.setPadding(0, pad, 0, 4)
            return t
        }

        root.addView(label("Step 1: set this app as your default digital assistant (then your corner swipe opens the chooser)."))
        val setDefault = Button(this)
        setDefault.text = "Open assistant settings"
        setDefault.setOnClickListener { startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)) }
        root.addView(setDefault)

        fun sideRow(side: String, title: String) {
            root.addView(label(title))
            val cycle = Button(this)
            val test = Button(this)
            fun refresh() {
                val o = Targets.options(this, side)
                val i = Targets.selected(this, side)
                cycle.text = "${i + 1}/${o.size}: ${o[i].label}  (tap to change)"
            }
            cycle.setOnClickListener {
                val o = Targets.options(this, side)
                Targets.setSelected(this, side, (Targets.selected(this, side) + 1) % o.size)
                refresh()
            }
            test.text = "Test launch"
            test.setOnClickListener { Targets.launch(this, side) }
            refresh()
            root.addView(cycle)
            root.addView(test)
        }

        root.addView(label("Step 2: pick + test what each side launches."))
        sideRow("gemini", "Gemini side (right)")
        sideRow("google", "Google side (left)")

        root.addView(label("Optional: custom component for the Google side (package/class), e.g. found via the list below."))
        val custom = EditText(this)
        custom.hint = "com.google.android.googlequicksearchbox/..."
        custom.setText(Targets.customComponent(this))
        root.addView(custom)
        val save = Button(this)
        save.text = "Save custom component"
        save.setOnClickListener { Targets.setCustomComponent(this, custom.text.toString()) }
        root.addView(save)

        root.addView(label("Hunting for the old overlay: list the Google app's exported screens."))
        val out = TextView(this)
        out.setTextIsSelectable(true)
        out.textSize = 11f
        val list = Button(this)
        list.text = "List Google app activities"
        list.setOnClickListener {
            out.text = try {
                val pi = packageManager.getPackageInfo(Targets.GOOGLE_PKG, PackageManager.GET_ACTIVITIES)
                pi.activities?.filter { it.exported }?.joinToString("\n") { it.name } ?: "none found"
            } catch (e: Exception) {
                "Error: $e"
            }
        }
        root.addView(list)
        root.addView(out)

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }
}
