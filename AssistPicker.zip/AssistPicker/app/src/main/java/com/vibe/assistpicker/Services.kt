package com.vibe.assistpicker

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionService
import android.view.View

class PickerService : VoiceInteractionService()

class PickerSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = PickerSession(this)
}

class PickerSession(ctx: Context) : VoiceInteractionSession(ctx) {
    override fun onCreateContentView(): View {
        return SplitView(context) { side ->
            Targets.launch(context, side)
            hide()
        }
    }
}

// Needed so Android lists us as a selectable assistant. Does nothing.
class StubRecognitionService : RecognitionService() {
    override fun onStartListening(recognizerIntent: Intent?, listener: Callback?) {}
    override fun onCancel(listener: Callback?) {}
    override fun onStopListening(listener: Callback?) {}
}
