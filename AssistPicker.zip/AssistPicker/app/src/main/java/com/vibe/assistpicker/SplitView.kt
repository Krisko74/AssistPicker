package com.vibe.assistpicker

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.os.Build
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs

/** Left half = Google, right half = Gemini. Swipe from an edge toward the middle (or tap) to pick. */
class SplitView(ctx: Context, private val onPick: (String) -> Unit) : View(ctx) {

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 64f
        isFakeBoldText = true
    }
    private val hint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 36f
    }

    private var downX = 0f
    private var curX = 0f
    private var side: String? = null
    private var dragging = false

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawColor(0x88000000.toInt())

        var leftEnd = w / 2
        var rightStart = w / 2
        if (dragging) {
            if (side == "google") leftEnd = maxOf(w / 2, curX)
            if (side == "gemini") rightStart = minOf(w / 2, curX)
        }

        fill.color = 0xCC4285F4.toInt()
        c.drawRect(0f, 0f, leftEnd, h, fill)
        fill.color = 0xCC8E6BF0.toInt()
        c.drawRect(rightStart, 0f, w, h, fill)

        c.drawText("Google", leftEnd / 2, h / 2, label)
        c.drawText("Gemini", (rightStart + w) / 2, h / 2, label)
        c.drawText("Swipe from the edge to the middle", w / 2, h * 0.12f, hint)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        if (Build.VERSION.SDK_INT >= 29) {
            // Ask the system not to treat edge swipes as Back (Android caps this at ~200dp tall per edge).
            val d = resources.displayMetrics.density
            val hh = (200 * d).toInt()
            val top = (h - hh) / 2
            val strip = (40 * d).toInt()
            systemGestureExclusionRects = listOf(
                Rect(0, top, strip, top + hh),
                Rect(w - strip, top, w, top + hh)
            )
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val w = width.toFloat()
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; curX = e.x
                side = if (e.x < w / 2) "google" else "gemini"
                dragging = true
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                curX = e.x
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                dragging = false
                val travelled = abs(curX - downX)
                val s = side
                if (s != null && (travelled > w * 0.3f || travelled < 20f)) onPick(s)
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> { dragging = false; invalidate() }
        }
        return true
    }
}
