package com.vibe.assistpicker

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.Toast

/** What each side launches. Options are guesses; the app lets you cycle + test until one works. */
object Targets {
    const val GEMINI_PKG = "com.google.android.apps.bard"
    const val GOOGLE_PKG = "com.google.android.googlequicksearchbox"

    class Option(val label: String, val make: (Context) -> Intent?)

    private fun act(action: String, pkg: String): (Context) -> Intent? = {
        Intent(action).setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    private fun opener(pkg: String): (Context) -> Intent? = { c ->
        c.packageManager.getLaunchIntentForPackage(pkg)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    private val gemini = listOf(
        Option("ASSIST to Gemini app", act(Intent.ACTION_ASSIST, GEMINI_PKG)),
        Option("VOICE_COMMAND to Gemini app", act(Intent.ACTION_VOICE_COMMAND, GEMINI_PKG)),
        Option("Just open Gemini app", opener(GEMINI_PKG))
    )

    private val google = listOf(
        Option("ASSIST to Google app", act(Intent.ACTION_ASSIST, GOOGLE_PKG)),
        Option("VOICE_COMMAND to Google app", act(Intent.ACTION_VOICE_COMMAND, GOOGLE_PKG)),
        Option("WEB_SEARCH in Google app", act("android.intent.action.WEB_SEARCH", GOOGLE_PKG)),
        Option("Just open Google app", opener(GOOGLE_PKG))
    )

    private fun prefs(c: Context) = c.getSharedPreferences("p", Context.MODE_PRIVATE)

    fun customComponent(c: Context): String = prefs(c).getString("custom", "")?.trim().orEmpty()

    fun setCustomComponent(c: Context, v: String) {
        prefs(c).edit().putString("custom", v.trim()).apply()
    }

    fun options(c: Context, side: String): List<Option> {
        if (side == "gemini") return gemini
        val custom = customComponent(c)
        if (custom.isEmpty()) return google
        return google + Option("Custom: $custom") {
            Intent().setComponent(ComponentName.unflattenFromString(custom))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    fun selected(c: Context, side: String): Int =
        prefs(c).getInt(side, 0).coerceIn(0, options(c, side).size - 1)

    fun setSelected(c: Context, side: String, i: Int) {
        prefs(c).edit().putInt(side, i).apply()
    }

    fun launch(c: Context, side: String) {
        val opt = options(c, side)[selected(c, side)]
        try {
            val intent = opt.make(c)
            if (intent == null) {
                Toast.makeText(c, "App not found for: ${opt.label}", Toast.LENGTH_LONG).show()
                return
            }
            c.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(c, "Failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
